<?php

use yii\helpers\Html;
use yii\grid\GridView;
use yii\helpers\StringHelper;
use kartik\date\DatePicker;
use yii\helpers\ArrayHelper;
use backend\models\Penduduk;
use backend\models\PendLuar;

/* @var $this yii\web\View */
/* @var $searchModel backend\models\SuratSearch */
/* @var $dataProvider yii\data\ActiveDataProvider */

$this->title = 'Surat Keterangan Penyataan';
$this->params['breadcrumbs'][] = $this->title;
?>
<div class="surat-index">
    <div class="box box-solid box-info">
        <div class="box-header">
            <center><h3 class="box-title">Data <?= Html::encode($this->title) ?></h3></center>
        </div>

    <div class="box-body">
    <?= GridView::widget([
        'dataProvider' => $dataProvider,
        'filterModel' => $searchModel,
        'columns' => [
           [
                'header' => 'Nama Penduduk Desa',
                'headerOptions' => ['style'=>'text-align:center; white-space: normal;'],
                'contentOptions' => ['style' => 'width:20%; white-space: normal;'],
                'attribute'=>'penduduk.NAMA_LGKP',
                'value' => 'penduduk.NAMA_LGKP',   
                'filter' => \kartik\select2\Select2::widget([
                    'model' => $searchModel,
                    'options' => ['placeholder' => 'Pilih Nama Penduduk',],
                    'pluginOptions' => ['allowClear' => true],
                    'attribute' => 'id_penduduk',
                    'data' => ArrayHelper::map(Penduduk::find()->all(), 'penduduk_id', 'NAMA_LGKP')
                    ]),
                
            ],
            [
                'header' => 'Nama Penduduk Daerah',
                'headerOptions' => ['style'=>'text-align:center; white-space: normal;'],
                'contentOptions' => ['style' => 'width:20%; white-space: normal;'],
                'attribute'=>'pendLuar.NAMA_LGKP',
                'value' => 'pendLuar.NAMA_LGKP',   
                'filter' => \kartik\select2\Select2::widget([
                    'model' => $searchModel,
                    'options' => ['placeholder' => 'Pilih Nama Penduduk',],
                    'pluginOptions' => ['allowClear' => true],
                    'attribute' => 'id_pend_luar',
                    'data' => ArrayHelper::map(PendLuar::find()->all(), 'pend_luar_id', 'NAMA_LGKP')
                    ]),
                
            ],
            [   
                'header' => 'Tanggal Surat',
                'attribute'=>'tanggal',
                'headerOptions' => ['style'=>'text-align:center; white-space: normal;'],
                'contentOptions' => ['style' => 'width:20%; white-space: normal;'],
                'format'=>['Date','php:l, d F Y', 'long'],
                    'filter'=>DatePicker::widget([
                    'model' => $searchModel,
                    'options' => ['placeholder' => 'Pilih Tanggal'],
                    'attribute'=>'tanggal',
                        'pluginOptions' => [
                            'autoclose' => true,
                            'format' => 'yyyy-mm-dd'
                        ]
                    ])      
            ],
            [
                'header' => 'Keterangan',
                'headerOptions' => ['style'=>'text-align:center; white-space: normal;'],
                'contentOptions' => ['style' => 'width:20%; white-space: normal;'],
                'attribute'=>'keterangan',
                'value' => function ($data){
                   if ($data->keterangan == NULL) {
                                return '' ;
                            } else {
                                return $data->keterangan;
                            }
                        },
                
            ],
        ],
    ]); ?>
    <br>
        <div class="form-group">
            <?= Html::a('<i class="fa fa-arrow-left"></i> Kembali',['index'],['class'=>'btn btn-default']); ?>
            </div>
</div>
</div>
</div>
