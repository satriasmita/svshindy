<?php
use yii\helpers\Url;
use yii\helpers\Html;
use yii\grid\GridView;
use yii\helpers\ArrayHelper;
use kartik\date\DatePicker;
use backend\models\Pekerjaan;
use backend\models\Pegawai;
use yii\helpers\StringHelper;
use yii\widgets\LinkPager;

/* @var this yii\web\View */

$this->title = 'Dashboard Aplikasi';
?>
<style type="text/css">
    marquee p
{
    white-space:nowrap;
}
table, th, td {
   border: 1px solid;
}
</style>
<div class="site-index">
  <div class="row">
  
  <div class="col-md-12">

    <div class="box box-widget widget-user">
      <!-- Add the bg color to the header using any of the bg-* classes -->
      <div class="widget-user-header bg-white"><center>
        <h3 class="widget-user-username" style="margin-top:20px">DATA SURAT DI DESA KAMPUNG BARU</h3></center>
        <!-- <h5 class="widget-user-desc">Founder &amp; CEO</h5> -->
      </div>
      <div class="widget-user-image" style="width:70px; margin-left:-500px;margin-top:-50px" >
        <img class="img" src="<?php echo Url::to('@web/images/logoo.png')?>" alt="logo" style="width:100px; margin-left:0px">
      </div>
    <br>
      <div class="col-md-12" onclick="window.location='<?= Url::to(['/site/ultah'])?>';">
    <table width="100%">
        <!-- <tbody> -->
          <tr>
            <td width="13%">&nbsp; Penduduk Berulang Tahun</td>
            <td width="75%"><?php if ($ultah==NULL) { ?>
    <marquee behavior="scroll" direction="left" style="font-size: 28px; font-weight: 600; color: #FFF;padding-top: 5px;padding-bottom: 5px;" bgcolor="#2d4acc" scrollamount="1"><p style="font-size: 12px">
        Belum Ada Data </p>
    </marquee>
    <?php } else { ?>
     <marquee behavior="scroll" direction="left" style="font-size: 28px; font-weight: 600; color: #FFF;padding-top: 5px;padding-bottom: 5px;" bgcolor="#2d4acc" scrollamount="3"><p style="font-size: 12px">
      <?php foreach ($ultah as $running) {?>
        <?= $running->NAMA_LGKP.','; ?> &nbsp&nbsp
        <?php } ?></p>
    </marquee>
    <?php } ?></td>
            <td width="7%" >&nbsp<?= $totalpelanggan?> Penduduk</td>

      </tr>
        <!-- </tbody> -->
      </table>
    </div>
    <br>
    <br>
      <div class="box-footer">
    <div class="row">
      <div class="col-md-3">
    <!-- Info Boxes Style 2 -->
    <div class="info-box bg-blue" onclick="window.location='<?= Url::to(['/site/skak'])?>';">
      <span class="info-box-icon"><i class="fa fa-child"></i></span>
      <div class="info-box-content">
        <span class="info-box-text">Surat Keterangan <br> Anak Kandung</span>
        <h3>
              <?= $totalskak?> SURAT
            </h3>
      </div>
    </div>
    <div class="info-box bg-blue" onclick="window.location='<?= Url::to(['/site/skawh'])?>';">
      <span class="info-box-icon"><i class="fa fa-wheelchair"></i></span>
      <div class="info-box-content">
        <span class="info-box-text">Surat Keterangan <br> Ahli Waris/Haji</span>
        <h3>
             <?= $totalskawh?> SURAT
            </h3>
      </div>
    </div>
    <div class="info-box bg-blue" onclick="window.location='<?= Url::to(['/site/skawm'])?>';">
      <span class="info-box-icon"><i class="fa fa-hotel"></i></span>
      <div class="info-box-content">
        <span class="info-box-text">Surat Keterangan <br> Ahli Waris/Meninggal</span>
        <h3>
              <?= $totalskawm?> SURAT
            </h3>
      </div>
    </div>
    <div class="info-box bg-blue" onclick="window.location='<?= Url::to(['/site/skb'])?>';">
      <span class="info-box-icon"><i class="fa fa-home"></i></span>
      <div class="info-box-content">
        <span class="info-box-text">Surat Keterangan <br> Berdomisili</span>
        <h3>
              <?= $totalskb?> SURAT
            </h3>
      </div>
    </div>
  <div class="info-box bg-blue" onclick="window.location='<?= Url::to(['/site/skbm'])?>';">
      <span class="info-box-icon"><i class="fa fa-heartbeat"></i></span>
      <div class="info-box-content">
        <span class="info-box-text">Surat Keterangan <br> Belum Menikah</span>
        <h3>
              <?= $totalskbm?> SURAT
            </h3>
      </div>
    </div>
    <div class="info-box bg-blue" onclick="window.location='<?= Url::to(['/site/skbpr'])?>';">
      <span class="info-box-icon"><i class="fa fa-home"></i></span>
      <div class="info-box-content">
        <span class="info-box-text">Surat Keterangan <br> Belum Punya Rumah</span>
        <h3>
             <?= $totalskbpr?> SURAT
            </h3>
      </div>
    </div>
    <div class="info-box bg-blue" onclick="window.location='<?= Url::to(['/site/skd'])?>';">
      <span class="info-box-icon"><i class="fa fa-mars"></i></span>
      <div class="info-box-content">
        <span class="info-box-text">Surat Keterangan <br> Duda</span>
        <h3>
              <?= $totalskd?> SURAT
            </h3>
      </div>
    </div>
  </div>
  <div class="col-md-3">
    <!-- Info Boxes Style 2 -->
    <div class="info-box bg-blue" onclick="window.location='<?= Url::to(['/site/skgh'])?>';">
      <span class="info-box-icon"><i class="fa fa-question"></i></span>
      <div class="info-box-content">
        <span class="info-box-text">Surat Keterangan <br> Ghaib</span>
        <h3>
             <?= $totalskgh?> SURAT
            </h3>
      </div>
    </div>
    <div class="info-box bg-blue" onclick="window.location='<?= Url::to(['/site/skh'])?>';">
      <span class="info-box-icon"><i class="fa fa-recycle"></i></span>
      <div class="info-box-content">
        <span class="info-box-text">Surat Keterangan <br> Hilang</span>
        <h3>
              <?= $totalskh?> SURAT
            </h3>
      </div>
    </div>
    <div class="info-box bg-blue" onclick="window.location='<?= Url::to(['/site/skj'])?>';">
      <span class="info-box-icon"><i class="fa fa-venus"></i></span>
      <div class="info-box-content">
        <span class="info-box-text">Surat Keterangan <br> Janda</span>
        <h3>
              <?= $totalskj?> SURAT
            </h3>
      </div>
    </div>
    <div class="info-box bg-blue" onclick="window.location='<?= Url::to(['/site/skk'])?>';">
      <span class="info-box-icon"><i class="fa fa-reply"></i></span>
      <div class="info-box-content">
        <span class="info-box-text">Surat Keterangan <br> Kerja</span>
        <h3>
             <?= $totalskk?> SURAT
            </h3>
      </div>
    </div>
    <div class="info-box bg-blue" onclick="window.location='<?= Url::to(['/site/skkb'])?>';">
      <span class="info-box-icon"><i class="fa fa-plus-square"></i></span>
      <div class="info-box-content">
        <span class="info-box-text">Surat Keterangan <br> Kelakuan Baik</span>
        <h3>
              <?= $totalskkb?> SURAT
            </h3>
      </div>
    </div>
    <div class="info-box bg-blue" onclick="window.location='<?= Url::to(['/site/skmd'])?>';">
      <span class="info-box-icon"><i class="fa fa-hotel"></i></span>
      <div class="info-box-content">
        <span class="info-box-text">Surat Keterangan <br> Meninggal Dunia</span>
        <h3>
              <?= $totalskmd?> SURAT
            </h3>
      </div>
    </div>
  <div class="info-box bg-blue" onclick="window.location='<?= Url::to(['/site/skn'])?>';">
      <span class="info-box-icon"><i class="fa fa-heart"></i></span>
      <div class="info-box-content">
        <span class="info-box-text">Surat Keterangan <br> Nikah</span>
        <h3>
              <?= $totalskn?> SURAT
            </h3>
      </div>
    </div>
  </div>
  <div class="col-md-3">
    <!-- Info Boxes Style 2 -->
    <div class="info-box bg-blue" onclick="window.location='<?= Url::to(['/site/skp'])?>';">
      <span class="info-box-icon"><i class="fa fa-money"></i></span>
      <div class="info-box-content">
        <span class="info-box-text">Surat Keterangan <br>  Penghasilan</span>
        <h3>
             <?= $totalskp?> SURAT
            </h3>
      </div>
    </div>
    <div class="info-box bg-blue" onclick="window.location='<?= Url::to(['/site/skpbb'])?>';">
      <span class="info-box-icon"><i class="fa fa-envelope-o"></i></span>
      <div class="info-box-content">
        <span class="info-box-text">Surat Keterangan <br> PBB</span>
        <h3>
              <?= $totalskpbb?> SURAT
            </h3>
      </div>
    </div>
    <div class="info-box bg-blue" onclick="window.location='<?= Url::to(['/site/sksk'])?>';">
      <span class="info-box-icon"><i class="fa fa-users"></i></span>
      <div class="info-box-content">
        <span class="info-box-text">Surat Keterangan <br> Susunan Keluarga</span>
        <h3>
             <?= $totalsksk?> SURAT
            </h3>
      </div>
    </div>
    <div class="info-box bg-blue" onclick="window.location='<?= Url::to(['/site/skst'])?>';">
      <span class="info-box-icon"><i class="fa fa-envelope"></i></span>
      <div class="info-box-content">
        <span class="info-box-text">Surat Keterangan <br> Pernyataan</span>
        <h3>
              <?= $totalskst?> SURAT
            </h3>
      </div>
    </div>
    <div class="info-box bg-blue" onclick="window.location='<?= Url::to(['/site/sktmi'])?>';">
      <span class="info-box-icon"><i class="fa fa-archive"></i></span>
      <div class="info-box-content">
        <span class="info-box-text">Surat Keterangan <br> Tidak Mampu</span>
        <h3>
              <?= $totalsktmi?> SURAT
            </h3>
      </div>
    </div>
    <div class="info-box bg-blue" onclick="window.location='<?= Url::to(['/site/sktmii'])?>';">
      <span class="info-box-icon"><i class="fa fa-archive"></i></span>
      <div class="info-box-content">
        <span class="info-box-text">Surat Keterangan <br> Tidak Mampu Orang Tua</span>
        <h3>
             <?= $totalsktmii?> SURAT
            </h3>
      </div>
    </div>
    <div class="info-box bg-blue" onclick="window.location='<?= Url::to(['/site/sktmp'])?>';">
      <span class="info-box-icon"><i class="fa fa-archive"></i></span>
      <div class="info-box-content">
        <span class="info-box-text">Surat Keterangan <br> Tidak Mampu Penghasilan</span>
        <h3>
              <?= $totalsktmp?> SURAT
            </h3>
      </div>
    </div>
  </div>
  <div class="col-md-3">
    <!-- Info Boxes Style 2 -->
    <div class="info-box bg-blue" onclick="window.location='<?= Url::to(['/site/sktt'])?>';">
      <span class="info-box-icon"><i class="fa fa-home"></i></span>
      <div class="info-box-content">
        <span class="info-box-text">Surat Keterangan <br> tempat tinggal</span>
        <h3>
              <?= $totalsktt?> SURAT
            </h3>
      </div>
    </div>
  <div class="info-box bg-blue" onclick="window.location='<?= Url::to(['/site/sku'])?>';">
      <span class="info-box-icon"><i class="fa fa-briefcase"></i></span>
      <div class="info-box-content">
        <span class="info-box-text">Surat Keterangan <br> Usaha</span>
        <h3>
              <?= $totalsku?> SURAT
            </h3>
      </div>
    </div>
    <div class="info-box bg-blue" onclick="window.location='<?= Url::to(['/site/skmdv'])?>';">
      <span class="info-box-icon"><i class="fa fa-warning"></i></span>
      <div class="info-box-content">
        <span class="info-box-text">Surat Keterangan Validasi<br>Meninggal Dunia</span>
        <h3>
             <?= $totalskmdv?> SURAT
            </h3>
      </div>
    </div>
    <div class="info-box bg-blue" onclick="window.location='<?= Url::to(['/site/skbse'])?>';">
      <span class="info-box-icon"><i class="fa fa-cc-jcb"></i></span>
      <div class="info-box-content">
        <span class="info-box-text">Surat Keterangan Validasi<br>BSE</span>
        <h3>
              <?= $totalskbse?> SURAT
            </h3>
      </div>
    </div>
    <div class="info-box bg-blue" onclick="window.location='<?= Url::to(['/site/skpindah'])?>';">
      <span class="info-box-icon"><i class="fa fa-exchange"></i></span>
      <div class="info-box-content">
        <span class="info-box-text">Surat Keterangan Validasi<br>Pindah</span>
        <h3>
             <?= $totalskpindah?> SURAT
            </h3>
      </div>
    </div>
    <div class="info-box bg-blue" onclick="window.location='<?= Url::to(['/site/sktditemukan'])?>';">
      <span class="info-box-icon"><i class="fa fa-arrows-alt"></i></span>
      <div class="info-box-content">
        <span class="info-box-text">Surat Keterangan Validasi<br>Tidak Ditemukan</span>
        <h3>
              <?= $totalsktditemukan?> SURAT
            </h3>
      </div>
    </div>
    <div class="info-box bg-blue" onclick="window.location='<?= Url::to(['/site/skbeasiswa'])?>';">
      <span class="info-box-icon"><i class="fa fa-money"></i></span>
      <div class="info-box-content">
        <span class="info-box-text">Surat Keterangan Validasi<br> Beasiswa</span>
        <h3>
              <?= $totalskbeasiswa?> SURAT
            </h3>
      </div>
    </div>
    <div class="info-box bg-blue" onclick="window.location='<?= Url::to(['/site/skbk'])?>';">
      <span class="info-box-icon"><i class="fa fa-institution"></i></span>
      <div class="info-box-content">
        <span class="info-box-text">Surat Keterangan Berdomisili Kantor</span>
        <h3>
              <?= $totalskbk?> SURAT
            </h3>
      </div>
    </div>
  </div>
  </div>
       
    </div>
  </div>
  </div>
</div>