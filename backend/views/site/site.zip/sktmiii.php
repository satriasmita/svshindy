<?php

use yii\helpers\Html;
use yii\grid\GridView;

/* @var $this yii\web\View */
/* @var $searchModel backend\models\SuratSearch */
/* @var $dataProvider yii\data\ActiveDataProvider */

$this->title = 'Surats';
$this->params['breadcrumbs'][] = $this->title;
?>
<div class="surat-index">
    <div class="box box-solid box-info">
        <div class="box-header">
            <center><h3 class="box-title">Data <?= Html::encode($this->title) ?></h3></center>
        </div>

    <div class="box-body">
    <?= GridView::widget([
        'dataProvider' => $dataProvider,
        'filterModel' => $searchModel,
        'columns' => [

            // 'surat_id',
            [
                'headerOptions' => ['style'=>'text-align:center; white-space: normal;'],
                'contentOptions' => ['style' => 'width:25%; white-space: normal;'],
                'attribute'=>'penduduk.NAMA_LGKP',
                'value' => function ($data){
                   if ($data->penduduk->NAMA_LGKP == NULL) {
                                return '' ;
                            } else {
                                return $data->penduduk->NAMA_LGKP;
                            }
                        },
                'label' => 'Nama Penduduk',
                
            ],
            [
                'header' => 'Nama Penduduk Daerah',
                'headerOptions' => ['style'=>'text-align:center; white-space: normal;'],
                'contentOptions' => ['style' => 'width:20%; white-space: normal;'],
                'attribute'=>'pendLuar.NAMA_LGKP',
                'value' => 'pendLuar.NAMA_LGKP',   
                'filter' => \kartik\select2\Select2::widget([
                    'model' => $searchModel,
                    'options' => ['placeholder' => 'Pilih Nama Penduduk',],
                    'pluginOptions' => ['allowClear' => true],
                    'attribute' => 'id_pend_luar',
                    'data' => ArrayHelper::map(PendLuar::find()->all(), 'pend_luar_id', 'NAMA_LGKP')
                    ]),
                
            ],
            [
                'label' => 'Tanggal Surat',
                'format' => 'html',
                'value' => function ($data){
                   if ($data->tanggal == NULL) {
                                return '' ;
                            } else {
                                return $data->tanggalIndo($data->tanggal);
                            }
                        }  
            ],
            [
                'headerOptions' => ['style'=>'text-align:center; white-space: normal;'],
                'contentOptions' => ['style' => 'width:25%; white-space: normal;'],
                'attribute'=>'jenis.nama_surat',
                'value' => function ($data){
                   if ($data->jenis->nama_surat == NULL) {
                                return '' ;
                            } else {
                                return $data->jenis->nama_surat;
                            }
                        },
                'label' => 'Jenis Surat',
                
            ],
        ],
    ]); ?>
</div>
</div>
</div>
